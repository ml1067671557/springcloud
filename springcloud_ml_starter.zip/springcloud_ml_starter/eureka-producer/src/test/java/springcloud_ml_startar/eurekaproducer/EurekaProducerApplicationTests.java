package springcloud_ml_startar.eurekaproducer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EurekaProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
